// Vercel serverless function: renders a NEXRAD radar product PNG
// Usage: /api/radar?station=KDMX&product=REF&tilt=1
// Products: REF, VEL, CC, ZDR, PHI, SW
// Returns: PNG image, 1000x1000, geo-registered (bounds in X-Bounds header)

import { createCanvas } from 'canvas';
import { Level2Radar } from '../lib/level2/src/index.js';

const BUCKET = 'https://unidata-nexrad-level2.s3.amazonaws.com';
const TIMEOUT_MS = 20000;

// Color palettes for each product (value → [r,g,b,a])
const PALETTES = {
  REF: [
    [-30, [0,0,0,0]], [0, [1,243,247,255]], [5, [21,123,167,255]],
    [10, [12,137,201,255]], [15, [36,221,121,255]], [20, [26,187,90,255]],
    [25, [17,154,59,255]], [30, [8,120,27,255]], [34, [128,175,19,255]],
    [35, [255,255,33,255]], [38, [255,199,0,255]], [44, [255,17,0,255]],
    [50, [154,0,0,255]], [55, [192,29,195,255]], [60, [247,108,237,255]],
    [65, [70,45,68,255]], [75, [142,142,142,255]], [95, [254,254,254,255]],
  ],
  VEL: [
    [-120, [255,0,128,255]], [-90, [0,0,160,255]], [-70, [0,224,255,255]],
    [-60, [0,255,224,255]], [-40, [0,255,0,255]], [-10, [16,96,16,255]],
    [0, [144,128,144,255]], [10, [112,0,0,255]], [40, [255,0,0,255]],
    [70, [255,96,0,255]], [120, [255,255,0,255]],
  ],
  CC: [
    [0, [15,15,140,255]], [0.6, [10,10,190,255]], [0.75, [120,120,255,255]],
    [0.80, [95,245,100,255]], [0.85, [135,215,10,255]], [0.90, [255,255,0,255]],
    [0.95, [255,140,0,255]], [0.97, [225,3,0,255]], [0.99, [139,30,77,255]],
    [1.05, [164,54,150,255]],
  ],
  ZDR: [
    [-7, [0,0,0,0]], [-3.5, [0,0,0,255]], [0, [255,255,255,255]],
    [0.5, [0,0,255,255]], [2, [0,255,0,255]], [2.5, [255,255,0,255]],
    [4.5, [255,0,0,255]], [6.5, [255,100,100,255]], [8, [255,255,255,255]],
  ],
  PHI: [
    [0, [0,0,0,255]], [30, [0,0,200,255]], [90, [0,200,255,255]],
    [180, [0,255,0,255]], [270, [255,255,0,255]], [360, [255,0,0,255]],
  ],
  SW: [
    [0, [20,5,72,255]], [2, [50,20,140,255]], [4, [124,38,190,255]],
    [7, [218,55,120,255]], [15, [251,126,33,255]], [18, [255,255,0,255]],
    [22, [153,255,51,255]], [30, [0,153,230,255]], [40, [255,255,255,255]],
  ],
};

function interpolateColor(palette, value) {
  if (value == null || isNaN(value)) return [0,0,0,0];
  const stops = palette;
  if (value <= stops[0][0]) return stops[0][1];
  if (value >= stops[stops.length-1][0]) return stops[stops.length-1][1];
  for (let i = 0; i < stops.length - 1; i++) {
    const [v0, c0] = stops[i];
    const [v1, c1] = stops[i+1];
    if (value >= v0 && value <= v1) {
      const t = (value - v0) / (v1 - v0);
      return [
        Math.round(c0[0] + (c1[0]-c0[0]) * t),
        Math.round(c0[1] + (c1[1]-c0[1]) * t),
        Math.round(c0[2] + (c1[2]-c0[2]) * t),
        Math.round(c0[3] + (c1[3]-c0[3]) * t),
      ];
    }
  }
  return [0,0,0,0];
}

// Fetch with timeout
async function fetchBuf(url) {
  const ctrl = new AbortController();
  const tid = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, { signal: ctrl.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}: ${url}`);
    return Buffer.from(await res.arrayBuffer());
  } finally {
    clearTimeout(tid);
  }
}

// List S3 prefix and return most recent key
async function latestKey(station) {
  const today = new Date();
  const pad = n => String(n).padStart(2,'0');
  const prefix = `${station}/${today.getUTCFullYear()}${pad(today.getUTCMonth()+1)}${pad(today.getUTCDate())}`;
  const url = `${BUCKET}?list-type=2&prefix=${prefix}&max-keys=100`;
  const xml = await fetchBuf(url);
  const text = xml.toString('utf8');
  const keys = [...text.matchAll(/<Key>([^<]+)<\/Key>/g)].map(m => m[1]);
  // Filter for archive files (not chunks, not metadata)
  const archives = keys.filter(k => /^\w{4}\/\d{8}_\d{6}$/.test(k));
  if (!archives.length) {
    // Try yesterday
    const yesterday = new Date(today.getTime() - 86400000);
    const prefix2 = `${station}/${yesterday.getUTCFullYear()}${pad(yesterday.getUTCMonth()+1)}${pad(yesterday.getUTCDate())}`;
    const url2 = `${BUCKET}?list-type=2&prefix=${prefix2}&max-keys=100`;
    const xml2 = await fetchBuf(url2);
    const text2 = xml2.toString('utf8');
    const keys2 = [...text2.matchAll(/<Key>([^<]+)<\/Key>/g)].map(m => m[1]);
    const archives2 = keys2.filter(k => /^\w{4}\/\d{8}_\d{6}$/.test(k));
    if (!archives2.length) throw new Error(`No Level2 files found for ${station}`);
    return archives2[archives2.length - 1];
  }
  return archives[archives.length - 1];
}

// Get moment data from Level2Radar based on product name
function getMomentData(radar, product) {
  switch (product) {
    case 'REF': return radar.getHighresReflectivity();
    case 'VEL': return radar.getHighresVelocity();
    case 'CC':  return radar.getHighresCorrelationCoefficient();
    case 'ZDR': return radar.getHighresDiffReflectivity();
    case 'PHI': return radar.getHighresDiffPhase();
    case 'SW':  return radar.getHighresSpectrum();
    default:    return radar.getHighresReflectivity();
  }
}

// Convert gate data to lat/lng bounding box and render to canvas
function renderRadar(radar, product, tilt, imgSize) {
  radar.setElevation(tilt);
  const palette = PALETTES[product] || PALETTES.REF;
  const azimuths = radar.getAzimuth();
  const headers  = radar.getHeader();
  const moments  = getMomentData(radar, product);

  // Station lat/lon from header
  const stLat = radar.header.latitude  * (Math.PI / 180);
  const stLon = radar.header.longitude * (Math.PI / 180);
  const R = 6371000;

  // Determine data bounds
  let minLat = Infinity, maxLat = -Infinity, minLon = Infinity, maxLon = -Infinity;

  // Collect all gate lat/lons for bounds
  const gatePts = [];
  for (let s = 0; s < azimuths.length; s++) {
    const moment = moments[s];
    if (!moment) continue;
    const az = azimuths[s] * (Math.PI / 180);
    const gateSize = moment.gate_size_m || 250;
    const firstGate = moment.first_gate_range_m || 0;
    const nGates = moment.data?.length || 0;
    for (let g = 0; g < nGates; g++) {
      const range = firstGate + g * gateSize;
      if (range > 460000) continue; // max 460km
      const dLat = (range * Math.cos(az)) / R;
      const dLon = (range * Math.sin(az)) / (R * Math.cos(stLat));
      const lat = (stLat + dLat) * (180 / Math.PI);
      const lon = (stLon + dLon) * (180 / Math.PI);
      minLat = Math.min(minLat, lat); maxLat = Math.max(maxLat, lat);
      minLon = Math.min(minLon, lon); maxLon = Math.max(maxLon, lon);
    }
    if (nGates > 0) gatePts.push(s);
  }

  if (!isFinite(minLat)) throw new Error('No valid radar data');

  // Add small margin
  const latMargin = (maxLat - minLat) * 0.01;
  const lonMargin = (maxLon - minLon) * 0.01;
  minLat -= latMargin; maxLat += latMargin;
  minLon -= lonMargin; maxLon += lonMargin;

  const canvas = createCanvas(imgSize, imgSize);
  const ctx = canvas.getContext('2d');
  const imgData = ctx.createImageData(imgSize, imgSize);
  const pixels = imgData.data;

  const latRange = maxLat - minLat;
  const lonRange = maxLon - minLon;

  for (let s = 0; s < azimuths.length; s++) {
    const moment = moments[s];
    if (!moment?.data) continue;
    const az = azimuths[s] * (Math.PI / 180);
    const gateSize = moment.gate_size_m || 250;
    const firstGate = moment.first_gate_range_m || 0;
    const nGates = moment.data.length;
    for (let g = 0; g < nGates; g++) {
      const raw = moment.data[g];
      if (raw == null || raw === 0) continue; // 0 = below threshold
      // decode value: (raw - offset) / scale per NEXRAD ICD
      const scale  = moment.scale  || 1;
      const offset = moment.offset || 0;
      const value  = (raw - offset) / scale;
      const color  = interpolateColor(palette, value);
      if (color[3] === 0) continue;

      const range = firstGate + g * gateSize;
      if (range > 460000) continue;

      // Gate center lat/lon
      const dLat = (range * Math.cos(az)) / R;
      const dLon = (range * Math.sin(az)) / (R * Math.cos(stLat));
      const lat  = (stLat + dLat) * (180 / Math.PI);
      const lon  = (stLon + dLon) * (180 / Math.PI);

      // Map to pixel (flip lat: top = maxLat)
      const px = Math.floor(((lon - minLon) / lonRange) * imgSize);
      const py = Math.floor(((maxLat - lat) / latRange) * imgSize);
      if (px < 0 || px >= imgSize || py < 0 || py >= imgSize) continue;

      // Paint a 2x2 block so small gates are visible
      for (let dy = 0; dy <= 1; dy++) {
        for (let dx = 0; dx <= 1; dx++) {
          const nx = px + dx, ny = py + dy;
          if (nx >= imgSize || ny >= imgSize) continue;
          const idx = (ny * imgSize + nx) * 4;
          if (pixels[idx+3] < color[3]) { // only overwrite if more opaque
            pixels[idx]   = color[0];
            pixels[idx+1] = color[1];
            pixels[idx+2] = color[2];
            pixels[idx+3] = color[3];
          }
        }
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);
  return { png: canvas.toBuffer('image/png'), bounds: { minLat, maxLat, minLon, maxLon } };
}

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  const station = (req.query.station || 'KDMX').toUpperCase().trim();
  const product = (req.query.product || 'REF').toUpperCase().trim();
  const tilt    = Math.max(1, Math.min(20, parseInt(req.query.tilt || '1', 10)));
  const imgSize = 1000;

  if (!/^K[A-Z0-9]{3}$/.test(station)) {
    res.status(400).json({ error: 'Invalid station' });
    return;
  }
  if (!PALETTES[product]) {
    res.status(400).json({ error: `Unknown product. Valid: ${Object.keys(PALETTES).join(', ')}` });
    return;
  }

  try {
    const key  = await latestKey(station);
    const buf  = await fetchBuf(`${BUCKET}/${key}`);
    const radar = new Level2Radar(buf, { logger: false, includeMoments: [product.toLowerCase() === 'ref' ? 'reflect' : product.toLowerCase() === 'vel' ? 'velocity' : product.toLowerCase() === 'cc' ? 'rho' : product.toLowerCase() === 'zdr' ? 'zdr' : product.toLowerCase() === 'phi' ? 'phi' : 'spectrum'] });
    const { png, bounds } = renderRadar(radar, product, tilt, imgSize);

    res.setHeader('Content-Type', 'image/png');
    res.setHeader('X-Bounds', JSON.stringify(bounds));
    res.setHeader('X-Station', station);
    res.setHeader('X-Product', product);
    res.setHeader('Cache-Control', 'public, max-age=120');
    res.status(200).send(png);
  } catch (err) {
    console.error('[radar]', err);
    res.status(500).json({ error: err.message });
  }
}
